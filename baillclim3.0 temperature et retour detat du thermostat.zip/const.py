
DOMAIN = "baillclim"
LOGIN_URL = "https://www.baillconnect.com/client/connexion"
REGULATIONS_URL = "https://www.baillconnect.com/client/regulations/XXXXXX"  #<<<<<< A MODIFIER AVEC VOTRE ID
COMMAND_URL = "https://www.baillconnect.com/api-client/regulations/XXXXXXX" #<<<<<< A MODIFIER AVEC VOTRE ID

