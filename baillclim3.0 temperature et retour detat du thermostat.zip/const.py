
DOMAIN = "baillclim"
LOGIN_URL = "https://www.baillconnect.com/client/connexion"
REGULATIONS_URL = "https://www.baillconnect.com/client/regulations/270"
COMMAND_URL = "https://www.baillconnect.com/api-client/regulations/270"
