async def async_setup_entry(hass, entry, async_add_entities):
    return True
